define(["knockout", "text!joystick.display.html", "expo"], function (ko, template, expo) {
   var joystick = function (model) {

      var viewModel = {};
      var controlModel = model.control;
      var worker = model.worker;
      var editControl = model.openEditor;
      var id = model.id;
      //var mappedExpo = [];
      var mid = [];
      var max = [];
      var axisGraphData = [];
      var setupMidAndMax = function () {
         max[0] = (controlModel.size.width() - controlModel.joySize.width());
         mid[0] = (max[0] / 2);
         max[1] = (controlModel.size.height() - controlModel.joySize.height());
         mid[1] = (max[1] / 2);
      };
      var mapValue = function (axisId, value) {
         var axisObj = controlModel.axis()[axisId];
         var limitObj = axisObj.limits;
         var val = value;
         if (val < mid[axisId]) {
            val = expo.map(val, 0, mid[axisId], limitObj.min(), limitObj.center());
            return expo.mapExpo(val, limitObj.expo.below(), limitObj.min(), limitObj.center());

         } else {
            val = expo.map(val, mid[axisId], max[axisId], limitObj.center(), limitObj.max());
            return expo.mapExpo(val, limitObj.expo.above(), limitObj.center(), limitObj.max());
         }
      };
      var animateSpringTenion = function (element, property, axisId, joyProp) {
         var axisObj = controlModel.axis()[axisId];
         var viewModelAxis = viewModel.axis[axisId];
         var springTension = axisObj.springTension();
         if (springTension !== 0 && axisObj.enabled()) {
            element.animate(property, {
               duration: parseInt(springTension),
               queue: false,
               step: function (value) {
                  if (axisObj.enabled) {
                     var mapped = mapValue(axisId, value);
                     axisObj.currentValue(mapped.value);
                     var valueInt = parseInt(mapped.value);
                     viewModelAxis.currentServoPosition(valueInt);
                     worker.sendInputChange(axisObj.channel(), valueInt);
                  }
               },
               complete: function () {
                  viewModel[joyProp](property[0]);
               }
            });
         }
      };
      var moveToCenter = function (element) {
         var el = $(element);
         el.removeClass("move");
         animateSpringTenion(el, { left: mid[0] }, 0, "joyLeft");
         animateSpringTenion(el, { top: mid[1] }, 1, "joyTop");
      };
      var moveAxis = function (value, axisId) {
         var axisObj = controlModel.axis()[axisId];
         var viewModelAxis = viewModel.axis[axisId];
         var mapped = mapValue(axisId, value);
         var valueInt = parseInt(mapped.value);
         viewModelAxis.currentServoPosition(valueInt);
         axisObj.currentValue(mapped.value);
         worker.sendInputChange(axisObj.channel(), valueInt);
      };
      var move = function (data, evt) {
         var element = $(evt.target);
         element.addClass("move");
         element.clearQueue();
         element.stop();
         //TODO dont calc on the fly.
         var left = (evt.clientX - controlModel.position.X()) - (controlModel.joySize.width() / 2);
         var top = (evt.clientY - controlModel.position.Y()) - (controlModel.joySize.height() / 2);
         var lmitX = left <= 0 || left + controlModel.joySize.width() >= controlModel.size.width();
         var limitY = top <= 0 || top + controlModel.joySize.height() >= controlModel.size.height();

         var axis0 = controlModel.axis()[0];
         var axis1 = controlModel.axis()[1];

         if (!lmitX) {
            if (axis0.enabled()) {
               viewModel.joyLeft(left);
               moveAxis(left, 0);
            }

         }
         if (!limitY) {
            if (axis1.enabled()) {
               viewModel.joyTop(top);
               moveAxis(top, 1);
            }
         }
      };
      var down = function (data, evt) {
         if (evt.target.setPointerCapture) {
            evt.target.setPointerCapture(evt.originalEvent.pointerId);
         }
      };
      var up = function (data, evt) {
         if (evt.target.releasePointerCapture) {
            evt.target.releasePointerCapture(evt.originalEvent.pointerId);
         }   
         moveToCenter(evt.target);
      };
      var out = function (data, evt) {
         moveToCenter(evt.target);
      };
      var preventContext = function (evt) {
         evt.preventDefault();
      };
      var expoChange = function () {
         ko.utils.arrayForEach(controlModel.axis(), function (axis, i) {
            var viewModelAxis = viewModel.axis[i];
            var valueInt = parseInt(axis.limits.center());
            viewModelAxis.currentServoPosition(valueInt);
            axis.currentValue(axis.limits.center());
            worker.sendInputChange(axis.channel(), valueInt);
         });
      }
      var edit = function () {
         var model = {
            axisGraphData: axisGraphData,
            control: controlModel,
            expoOnChange: expoChange,
            id: id
         }
         editControl(model, "joystick.editor.html");
      };

      viewModel.left = controlModel.position.X;
      viewModel.top = controlModel.position.Y;
      viewModel.width = controlModel.size.width;
      viewModel.height = controlModel.size.height;
      viewModel.joyWidth = controlModel.joySize.width;
      viewModel.joyHeight = controlModel.joySize.height;

      setupMidAndMax();

      viewModel.joyLeft = ko.observable(mid[0]).extend({
         rateLimit: (1000 / 200),
         notify: "always"
      });
      viewModel.joyTop = ko.observable(mid[1]).extend({
         rateLimit: (1000 / 200),
         notify: "always"
      });

      viewModel.axis = [];
      ko.utils.arrayForEach(controlModel.axis(), function (axis) {
         axis.currentValue(axis.limits.center());
         worker.sendInputChange(axis.channel(),axis.limits.center());
         viewModel.axis.push({
            enabled: axis.enabled,
            channel: axis.channel,
            currentServoPosition: ko.observable(axis.limits.center()).extend({
               notify: "always",
               rateLimit: model.RefreshRate()
            })
         });
      });

      viewModel.width.subscribe(function () {
         setupMidAndMax();
         viewModel.joyLeft(mid[0]);
      });
      viewModel.height.subscribe(function () {
         setupMidAndMax();
         viewModel.joyTop(mid[1]);
      });

      viewModel.edit = edit;
      viewModel.move = move;
      viewModel.up = up;
      viewModel.out = out;
      viewModel.down = down;
      viewModel.preventContext = preventContext;

      model.finishedLoading({ id: model.id });



      return viewModel;
   }

   return {
      viewModel: joystick,
      template: template
   }
});