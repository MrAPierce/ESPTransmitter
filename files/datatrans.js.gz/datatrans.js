﻿// web worker
var ws = null;
var transmitter = null;
var bufferedAmount = 72;
var dataRate = 20;
var data = null;
var url = null;

self.addEventListener("message", function (e) {

   switch (e.data.cmd) {
      case "setupSocket":
         data = new Uint16Array(16);
         url = e.data.url;
         SetupWebSocket();
         break;
      case "bufferAmount":
         bufferedAmount = e.data.amount;
         postMessage({ type: "lgs", data: [{ type: "log", message: "Buffered Amount updated to: " + e.data.amount }] });
         break;
      case "dataRate":
         dataRate = e.data.rate;
         StopTrans();
         postMessage({ type: "lgs", data: [{ type: "log", message: "Data rate updated to: " + parseInt(1000 / e.data.rate) + " req/s" }] });
         StartTrans();
         break;
      case "startTrans":
         StartTrans();
         break;
      case "stopTrans":
         StopTrans();
         break;
      case "serverRequest":
         SendServerRequest({ type: "sr", cmd: e.data.request });
         break;
      case "inputChange":
         data[e.data.input.channel] = e.data.input.value;
         break;
      case "unload":
         ws.close();
         break;

      default:
         postMessage({ type: "lgs", data: [{ type: "log", message: "Unknown transmitter Command: " + e.data.cmd }] });
   }

});


function SetupWebSocket() {
   try {
      ws = new WebSocket(url);
      ws.onopen = function() {
         postMessage({ type: "lgs", data: [{ type: "log", message: "hot diggity daffodil, reciever connection established" }] });
      }
      ws.onmessage = function (event) {
         //event.data instanceof ArrayBuffer
         //event.data instanceof Blob
         if (typeof event.data === "string") {
            try {
               var object = JSON.parse(event.data);
               postMessage(object);
            } catch (e) {
               postMessage({ type: "lgs", data: [{ type: "error", message: "data recieved from reciever was malformed or incomplete" }] });
            } 
         }
      }
      ws.onclose = function (event) {

         //TODO  make user friendly
         var reason;
         // See http://tools.ietf.org/html/rfc6455#section-7.4.1
         if (event.code === 1001)
            reason = "An endpoint is \"going away\", such as a server going down or a browser having navigated away from a page.";
         else if (event.code === 1002)
            reason = "An endpoint is terminating the connection due to a protocol error";
         else if (event.code === 1003)
            reason = "An endpoint is terminating the connection because it has received a type of data it cannot accept (e.g., an endpoint that understands only text data MAY send this if it receives a binary message).";
         else if (event.code === 1004)
            reason = "Reserved. The specific meaning might be defined in the future.";
         else if (event.code === 1005)
            reason = "No status code was actually present.";
         else if (event.code === 1006)
            reason = "The connection was closed abnormally, e.g., without sending or receiving a Close control frame";
         else if (event.code === 1007)
            reason = "An endpoint is terminating the connection because it has received data within a message that was not consistent with the type of the message (e.g., non-UTF-8 [http://tools.ietf.org/html/rfc3629] data within a text message).";
         else if (event.code === 1008)
            reason = "An endpoint is terminating the connection because it has received a message that \"violates its policy\". This reason is given either if there is no other sutible reason, or if there is a need to hide specific details about the policy.";
         else if (event.code === 1009)
            reason = "An endpoint is terminating the connection because it has received a message that is too big for it to process.";
         else if (event.code === 1010) // Note that this status code is not used by the server, because it can fail the WebSocket handshake instead.
            reason = "An endpoint (client) is terminating the connection because it has expected the server to negotiate one or more extension, but the server didn't return them in the response message of the WebSocket handshake. <br /> Specifically, the extensions that are needed are: " + event.reason;
         else if (event.code === 1011)
            reason = "A server is terminating the connection because it encountered an unexpected condition that prevented it from fulfilling the request.";
         else if (event.code === 1015)
            reason = "The connection was closed due to a failure to perform a TLS handshake (e.g., the server certificate can't be verified).";
         else
            reason = "Unknown reason";

         postMessage({ type: "lgs", data: [{ type: "error", message: "trasnmitter connection closed: " + reason }] });

         if (transmitter != null) {
            StopTrans();
         }
      }
      ws.onerror = function () {
         postMessage({ type: "lgs", data: [{ type: "error", message: "trasnmitter connection error, cannot connect to reciever" }] });
      }
   }
   catch (e) {
      postMessage({ type: "lgs", data: [{ type: "error", message: "Error creating trasnmitter connection: " + e.message }] });
   }
}

function StartTrans() {
   if (ws != null) {
      if (ws.readyState === 1) {
         transmitter = setInterval(function () {
            if (ws.bufferedAmount < bufferedAmount && data != null) {
               ws.send(data, { binary: true, mask: true });
            }
         }, dataRate);
      }
      else {
         postMessage({ type: "lgs", data: [{ type: "error", message: "trasnmitter connection cannot transmit in current state, trying to reconnect" }] });
         ws = null;
         SetupWebSocket();
      }
   }
   else {
      postMessage({ type: "lgs", data: [{ type: "error", message: "Socket Object is null, please check connecion to server" }] });
   }
}

function StopTrans() {
   if (transmitter) {
      clearInterval(transmitter);
      //postMessage({ type: "transmitter", action: "stopped" });
   }

}

function SendServerRequest(data) {
   if (ws.readyState === 1) {
      ws.send(JSON.stringify(data), { binary: false, mask: false });
   } else {
      postMessage({ type: "lgs", data: [{ type: "error", message: "trasnmitter connection cannot transmit in current state, trying to reconnect" }] });
   }
}
