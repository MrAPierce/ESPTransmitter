﻿define(['knockout','expo'], function (ko,expo) {

   var viewModel = function (params) {
      return params;
   }

   return viewModel;
});