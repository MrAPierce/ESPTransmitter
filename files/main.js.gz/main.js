requirejs(["knockout", "mapping", "worker", "toast", "defaults", "jquery", "chartjs", "bindingHanlders"], function (ko, koMapping, worker, toast) {

   toast.options = {
      "closeButton": false,
      "debug": false,
      "newestOnTop": false,
      "progressBar": false,
      "positionClass": "toast-bottom-left",
      "preventDuplicates": true,
      "onclick": null,
      "showDuration": "1000",
      "hideDuration": "10000",
      "timeOut": "5000",
      "extendedTimeOut": "1000",
      "showEasing": "swing",
      "hideEasing": "linear",
      "showMethod": "fadeIn",
      "hideMethod": "fadeOut"
   }

   //toast["info"]("Hello","", { onclick: function () { alert('fsdgdfg') } });

   $(document).on("touchmove", function (evt) { evt.preventDefault() });
   $(document).on("touchmove", ".scrollable", function (evt) { evt.stopPropagation() });

   var loading = [];
   var actualDataRate = ko.observable(0);
   var memoryUsage = ko.observable();
   var uiRefresh = ko.observable(1000 / 25);
   var moveEnabled = ko.observable(false);
   var ignoreInfo = ko.observable(false);
   var addControlOpen = ko.observable(false);
   var controlModels = ko.observableArray([]);
   var installedModel = ko.observableArray();
   var transmitting = ko.observable(false);
   var scanning = ko.observable(false);
   var availableWifi = ko.observableArray();

   var editing = ko.observable(false);
   var editor = document.getElementById("editor");
   var editorContent = document.getElementById("editorPane");

   //TODO move somewhere else and is it always going to be one pca9685?
   var channels = new Array(16);
   var springTension = [{
      name: "None",
      value: 0
   }, {
      name: "Hard",
      value: 150
   }, {
      name: "Medium",
      value: 300
   }, {
      name: "Soft",
      value: 600
   }];
   for (var i = 0; i < channels.length; i++) {
      channels[i] = i;
   }
   //

   var wsUri = "ws://" + location.host + "/";
   var webworkerMessageHandler = function (event) {
      if (typeof event.data === "object") {
         var incoming = event.data;
         if (incoming.type === "lgs") {
            incoming.data.forEach(function(logData) {
               if (logData.type === "error") {
                  toast["error"](logData.message);
               } else {
                  if (ignoreInfo() === false) {
                     toast["info"](logData.message);
                  }
               }
            });
         }
         if (incoming.type === "console") {
            //console.log(incoming.message);
         }
         if (incoming.type === "sdr") {
            //$(window).trigger(incoming.dt + "_" + incoming.idx + "_data", incoming.result);
         }
         if (incoming.type === "os") {
            actualDataRate(incoming.data.rate);
            memoryUsage(incoming.data.mem);
            scanning(incoming.data.scan);
         }
         if (incoming.type === "wifi") {
            scanning(false);
            if (incoming.failed) {
               toast["error"]("Wifi scan failed, please try agin.");
            } else {
               toast["info"]("Wifi scan complete");
               availableWifi.removeAll();
               var wifi = incoming.available;
               for (var j = 0; j < wifi.length; j++) {
                  availableWifi.push(wifi);
               }
            }
         }
      }
   }

   function registerComponent(controlType) {
      if (ko.components.isRegistered(controlType) === false) {
         ko.components.register(controlType, {
            require: controlType
         });
      }
   }

   var close = function () {
      editing(false);
      editorContent.innerHTML = "";
      ko.cleanNode(editor);
   };

   var save = function (id, control) {
      window.defaultControls[id] = control;
      console.log(JSON.stringify(window.defaultControls));
      localStorage.controls = JSON.stringify(window.defaultControls);
      //TODO send to server
   };

   var saveAll = function() {
      ko.utils.arrayForEach(controlModels(), function (item) {
         var control, id;
         if (item.getControlModel) {
            var model = item.getControlModel();
            control = koMapping.toJS(model.control);
            id = model.id;
         } else {
            control = koMapping.toJS(item.control);
            id = item.id;
         }
         save(id, control);
      });

   }

   var deleteControl = function (koModel) {
      var sure = confirm("Delete " + koModel.model.control.name() + "?");
      if (sure) {
         controlModels.remove(function (controlModel) { return controlModel.id === koModel.model.id });
         saveAll();
         close();
      }
   }

   var openEditor = function (controlModel, editTemplate) {
      require(["text!" + editTemplate], function (editTemplate) {
         editorContent.innerHTML = editTemplate;
         ko.cleanNode(editor);
         var viewModel = {
            model: controlModel,
            channels: channels,
            springTension: springTension,
            save: saveAll,
            deleteControl: deleteControl,
            close: close
         };
         ko.applyBindings(viewModel, editor);
         editing(true);
      });
   };

   var getControlByType = function (controlTypes /* , excludeControls */) {
      var controlResults = [];
      controlModels().forEach(function (model, i) {
         //TODO controls should tell if and how they can be used for mixing
         var control = model.control;
         if (controlTypes.indexOf(control.type()) !== -1) {
            controlResults.push({ id: i, control: control });
         }
      });
      return controlResults;
   }

   var getControlById = function (id) {
      var controlResult;
      controlModels().forEach(function (control) {
         if (control.id === id) {
            controlResult = controlModels()[id].control;
         }
      });
      return controlResult;
   }

   var loadingComplete = function (item) {
      loading.forEach(function (loadingItem, i) {
         if (loadingItem.id === item.id) {
            loading.splice(i, 1);
         }
      });

      if (loading.length === 0) {
         var loadIndicator = document.getElementById("loading");
         if (loadIndicator) {
            loadIndicator.className += " hide";
            setTimeout(function () {
               loadIndicator.parentElement.removeChild(loadIndicator);
            }, 500);
         }

      }
   }

   var addControl = function (control, i) {

      var type = control.type;
      registerComponent(type);

      controlModels.push({
         id: i,
         type: type,
         findControlById: getControlById,
         findControlsByType: getControlByType,
         control: koMapping.fromJS(control),
         rawControl: control,
         finishedLoading: loadingComplete,
         moveEnabled: moveEnabled,
         openEditor: openEditor,
         worker: worker,
         RefreshRate: uiRefresh
      });

   }

   var controlsModel = function () {

      self.editingControl = editing;

      if (localStorage.controls == null) {
         localStorage.controls = JSON.stringify(window.defaultControls);
      }

      var storedControls = JSON.parse(localStorage.controls);
      storedControls.forEach(function (control, i) {
         addControl(control, i);
         loading.push({ id: i });
      });

      return {
         controlModels: controlModels
      }
   };

   var systemSettingModel = function () {

      var viewModel = {};
      viewModel.bufferedAmount = ko.observable(74).extend({ rateLimit: { timeout: 200, method: "notifyWhenChangesStop" } });
      viewModel.dataRate = ko.observable(20).extend({ rateLimit: { timeout: 200, method: "notifyWhenChangesStop" } });
      viewModel.uiUpdate = ko.observable(25).extend({ rateLimit: { timeout: 200, method: "notifyWhenChangesStop" } });;
      viewModel.transmitting = transmitting;
      
      viewModel.actualDataRate = ko.computed(function () {
         //TODO why does this sporadically jump around?
         return actualDataRate() + " req/s";
      });

      viewModel.memoryUsage = ko.computed(function () {
            return (memoryUsage() / 1024).toFixed(2) + " kb";
      });

      viewModel.hasMemoryUsage = memoryUsage;
      viewModel.ignoreInfo = ignoreInfo;
      viewModel.settingsVisible = ko.observable(false);
      viewModel.addControlOpen = ko.observable(false);

      viewModel.dataRate.subscribe(function (value) {
         worker.sendCommand({ cmd: "dataRate", rate: value });
      });

      viewModel.bufferedAmount.subscribe(function (value) {
         worker.sendCommand({ cmd: "bufferAmount", amount: value });
      });

      viewModel.uiUpdate.subscribe(function (value) {
         toast["info"]("UI refresh rate changed to " + value + " fps");
         uiRefresh(1000 / value);
      });

      var enableMove = function () {
         moveEnabled(!moveEnabled());
      }

      var startTransmitting = function () {
         worker.sendCommand({ cmd: "startTrans" });
         viewModel.transmitting(true);
      }

      var stopTransmitting = function () {
         worker.sendCommand({ cmd: "stopTrans" });
         viewModel.transmitting(false);
      }

      var scanWifi = function () {
         if (scanning()) {
            toast["info"]("Already running scan, please wait.");
         } else {
            scanning(true);
            worker.sendCommand({ cmd: "serverRequest", request: "scanwifi" });
         }
      }

      var showSettings = function () {
         viewModel.settingsVisible(!viewModel.settingsVisible());
      }

      var addControl = function () {
         require(["installed"], function (installed) {
            installedModel(installed);
            addControlOpen(true);
         });
      }

      viewModel.startTransmitting = startTransmitting;
      viewModel.stopTransmitting = stopTransmitting;
      viewModel.uiRefresh = uiRefresh;
      viewModel.enableMove = enableMove;
      viewModel.openSettings = showSettings;
      viewModel.addControl = addControl;
      viewModel.wifiScan = scanWifi;

      return viewModel;
   }

   var addControlModel = function () {
      var viewModel = {};
      viewModel.installed = installedModel;
      viewModel.opened = addControlOpen();

      var addNew = function (control) {
         addControl(control.defaultModel, controlModels().length);
      }
      var close = function() {
         addControlOpen(false);
      }

      viewModel.add = addNew;
      viewModel.close = close;
      return viewModel;
   }

   setTimeout(function () {
      worker.setupTransmitter(wsUri, webworkerMessageHandler);
      ko.applyBindings(controlsModel, document.getElementById("controls"));
      ko.applyBindings(systemSettingModel, document.getElementById("tools"));
      ko.applyBindings(addControlModel, document.getElementById("addControlDialog"));
   }, 1000);

});