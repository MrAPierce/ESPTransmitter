﻿requirejs(["knockout"], function (ko) {

   ko.bindingHandlers.contextMenu = {
      init: function (element, valueAccessor, allBindings, bindingContext) {
         var value = valueAccessor(),
             events = function () {
                return {
                   MSHoldVisual: value,
                   contextmenu: value
                }
             };
         ko.bindingHandlers.event.init.call(this, element, events, allBindings, bindingContext)
      }
   };

   ko.bindingHandlers.chartType = {
      init: function (element, valueAccessor, allBindings) {
         if (!allBindings.has('chartData')) {
            throw Error('chartType must be used in conjunction with chartData and (optionally) chartOptions');
         }
      },
      update: function (element, valueAccessor, allBindings) {
         var ctx = element.getContext('2d'),
           type = ko.unwrap(valueAccessor()),
           data = ko.toJS(allBindings.get('chartData')),
           options = ko.unwrap(allBindings.get('chartOptions')) || {};

         if (Object.keys(data).length != 0) {
            // destroy old chart
            element.chart && element.chart.destroy();
            // create new
            var chart = new Chart(ctx)[type](data, options);
            element.chart = chart;
         }
      }
   };

   ko.bindingHandlers.chartData = {
      init: function (element, valueAccessor, allBindings) {
         if (!allBindings.has('chartType')) {
            throw Error('chartData must be used in conjunction with chartType and (optionally) chartOptions');
         }
      }
   };

   ko.bindingHandlers.chartOptions = {
      init: function (element, valueAccessor, allBindings) {
         if (!allBindings.has('chartData') || !allBindings.has('chartType')) {
            throw Error('chartOptions must be used in conjunction with chartType and chartData');
         }
      }
   };

   ko.bindingHandlers.numericValue = {
      init: function (element, valueAccessor, allBindings, data, context) {
         var interceptor = ko.computed({
            read: function () {
               return ko.unwrap(valueAccessor());
            },
            write: function (value) {
               if (!isNaN(value)) {
                  valueAccessor()(parseFloat(value));
               }
            },
            disposeWhenNodeIsRemoved: element
         });

         ko.applyBindingsToNode(element, { value: interceptor }, context);
      }
   };

   ko.components.register("axisExpoEditor", {
      viewModel: { require: "axisExpo" },
      template: { require: "text!axisExpo.display.html" }
   });

   ko.components.register("generalSettings", {
      viewModel: { require: "generalSettings" },
      template: { require: "text!generalSettings.editor.html" }
   });

});