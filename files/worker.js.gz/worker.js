﻿define(function () {

   var transmitter = new Worker("datatrans.js");
   var messenger;

   var setup = function (url, messageCallback) {
      if (url == null || url === "") {
         throw "Error, websocket url empty or not defined, please specify as first parameter";
      }

      messenger = messageCallback;
      transmitter.postMessage({ cmd: "setupSocket", url: url });
   }

   var send = function(data) {
      transmitter.postMessage({ cmd: "serverRequest", request: data });
   }

   var sendCommand = function (data) {
      transmitter.postMessage(data);
   }

   var sendInputChange = function(channel, value) {
      sendCommand({
         cmd: "inputChange",
         input: {
            channel: channel,
            value: value
         }
      });
   }

   transmitter.onmessage = function (event) {
      if (messenger) {
         messenger(event);
      }
   };

   return {
      setupTransmitter: setup,
      sendServerRequest: send,
      sendInputChange: sendInputChange,
      sendCommand: sendCommand
   }
   
});