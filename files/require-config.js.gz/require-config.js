//TODO remove jquery dependancy, only used for animate
require.config({
    paths: {
       knockout: "knockout-3.3.0",
       mapping: "knockout.mapping-latest",
       defaults: "defaults",
       jquery: "jquery",
       chartjs: "chart.min",
       bindingHanlders: "binding",
       mixing: "mixing",
       expo: "expo",
       worker: "worker",
       toast: "toastr.min",
       installed: "installed.controls"
    }
});