﻿define(function () {

   var installed = [
      {
         title: "Switch",
         defaultModel: {
            icon: "&#128280;",
            type: "switch",
            name: "New Servo switch Control",
            position: {
               X: 0,
               Y: 0
            },
            cssClass: "default",
            notes: "",
            groups: []
         }
      },
      {
         title: "Joystick",

         defaultModel:
   {
      icon: "&#127918;",
      type: "joystick",
      name:
         "New Joystick",
      notes:
         "",
      position:
      {
         X: 0,
         Y:
            0
      },
      size: {
         width: 300,
         height:
            300
      },
      joySize: {
         width: 65,
         height:
            65
      },
      cssClass: "default",
      panel:
         ".controls",
      axis:
      [
         {
            name: "X",
            channel: 1,
            axis: "X",
            enabled: true,
            springTension: 150,
            currentValue: 0,
            limits: {
               max: 560,
               min: 150,
               center: 327,
               rate: 100,
               expo: {
                  above: 1.5,
                  below: 1.5
               }
            }
         }, {
            name: "Y",
            channel: 0,
            axis: "Y",
            enabled: true,
            springTension: 150,
            currentValue: 0,
            limits: {
               max: 560,
               min: 150,
               center: 327,
               rate: 100,
               expo: {
                  above: 1.5,
                  below: 1.5
               }
            }
         }
      ]
   }
      },
      {
         title: "Servo Slave",
         defaultModel: {
            icon: "&#128123;",
            type: "servoslave",
            name: "New Slave Servo Control",
            position: {
               X: 0,
               Y: 0
            },
            cssClass: "default",
            notes: "",
            mixOutputs: []
         }
      }
   ];

   return installed;

});