﻿define(function () {

   var getValue = function (val, expo, from, to) {
      var value = from + Math.pow((val - from) / (to - from), expo) * (to - from);
      return {
         raw: val,
         value: value
      };
   }

   var map = function(s, a1, a2, b1, b2) {
      return b1 + (s - a1) * (b2 - b1) / (a2 - a1);
   }

   var getDataForLimit = function(dataSet, limit) {
      for (var i = 0; i <= 100; i += 10) {;
         var mapped;
         var betweenPercentage;
         if (i <= 50) {
            betweenPercentage = map(i, 50, 0, limit.center(), limit.min());
            mapped = getValue(betweenPercentage, limit.expo.below(), limit.center(), limit.min()).value;
         } else {
            betweenPercentage = map(i, 50, 100, limit.center(), limit.max());
            mapped = getValue(betweenPercentage, limit.expo.above(), limit.center(), limit.max()).value;
         }
         dataSet.data.push(parseInt(mapped));
      }
   }

   var graphModel = function (limit, parentLimit) {
      var model = {
         type: "Line",
         graphModel: {
            options: {
               responsive: true,
               maintainAspectRatio: true,
               bezierCurveTension: 0.1,
               scaleShowGridLines: true,
               scaleShowLabels: true,
               pointDot: false
            }
         }
      }

      model.graphModel.data = {};
      model.graphModel.data.labels = [];
      model.graphModel.data.datasets = [];

      model.graphModel.data.datasets[0] = {
         label: "Expo",
         fillColor: "rgba(220,220,220,0.2)",
         strokeColor: "rgba(220,220,220,1)",
         pointColor: "rgba(220,220,220,1)",
         pointStrokeColor: "#fff",
         pointHighlightFill: "#fff",
         pointHighlightStroke: "rgba(220,220,220,1)",
         data: []
      }

      for (var i = 0; i <= 100; i += 10) {
         model.graphModel.data.labels.push(i);
      }

      getDataForLimit(model.graphModel.data.datasets[0], limit);

      if (parentLimit) {
         model.graphModel.data.datasets[1] = {
            label: "Parent",
            fillColor: "rgba(220,220,220,0.0)",
            strokeColor: "rgba(215, 44, 44, 0.1)",
            pointColor: "rgba(220,220,220,1)",
            pointStrokeColor: "#fff",
            pointHighlightFill: "#fff",
            pointHighlightStroke: "rgba(220,220,220,1)",
            data: []
         }
         getDataForLimit(model.graphModel.data.datasets[1], parentLimit);
      }

      return model;
   };

   return {
      mapExpo: getValue,
      graphModel: graphModel,
      map: map
   }
});