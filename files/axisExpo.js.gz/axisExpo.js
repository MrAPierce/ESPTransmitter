﻿define(['knockout','expo'], function (ko,expo) {

   var viewModel = function (params) {

      var limits = params.limits;
      var parentLimits = params.parentlimits;

      var changeCallback = params.changeCallback;
      var model =
      {
         graphModel:
            ko.observable(expo.graphModel(limits, parentLimits)).extend({ rateLimit: { timeout: 300, method: "notifyWhenChangesStop" } }),
         limits: limits
      }

      var raiseExpoChanged = function(limit, value) {
         if (changeCallback) {
            changeCallback({ limit: limit, value: value });
         }
      }

      limits.center.subscribe(function (value) {
         model.graphModel(expo.graphModel(limits, parentLimits));
         raiseExpoChanged("center", value);
      });

      limits.max.subscribe(function (value) {
         model.graphModel(expo.graphModel(limits, parentLimits));
         raiseExpoChanged("max", value);
      });

      limits.min.subscribe(function (value) {
         model.graphModel(expo.graphModel(limits, parentLimits));
         raiseExpoChanged("min", value);
      });

      limits.expo.above.subscribe(function (value) {
         model.graphModel(expo.graphModel(limits, parentLimits));
         raiseExpoChanged("expoAbove", value);
      });

      limits.expo.below.subscribe(function (value) {
         model.graphModel(expo.graphModel(limits, parentLimits));
         raiseExpoChanged("expoBelow", value);
      });

      return model;
   }

   return viewModel;
});