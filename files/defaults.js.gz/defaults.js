window.defaultControls = [
   {
      "type": "joystick",
      "name": "Bucket-LArm",
      "icon": "&#127918;",
      "notes": "",
      "position": {
         "X": 113,
         "Y": 88
      },
      "size": {
         "width": 300,
         "height": 300
      },
      "joySize": {
         "width": 65,
         "height": 65
      },
      "cssClass": "default",
      "panel": ".controls",
      "axis": [
         {
            "name": "Bucket",
            "channel": 1,
            "axis": "X",
            "enabled": true,
            "springTension": 150,
            "currentValue": 327,
            "limits": {
               "max": 560,
               "min": 150,
               "center": 327,
               "rate": 100,
               "expo": {
                  "above": 1.5,
                  "below": 1.5
               }
            }
         },
         {
            "name": "Boom",
            "channel": 0,
            "axis": "Y",
            "enabled": true,
            "springTension": 150,
            "currentValue": 327,
            "limits": {
               "max": 560,
               "min": 150,
               "center": 327,
               "rate": 100,
               "expo": {
                  "above": 1.5,
                  "below": 1.5
               }
            }
         }
      ]
   },
   {
      "type": "servoslave",
      "icon": "&#128123;",
      "name": "Slave Servo Control1",
      "position": {
         "X": 580,
         "Y": 450
      },
      "cssClass": "default",
      "notes": "",
      "mixOutputs": [
         {
            "name": "Hydraulic Pump",
            "notes": "take both axis from left joystick and one axis from right and mix find the maximum",
            "enabled": true,
            "channel": 8,
            "type": "MixTypeMax",
            "currentValue": 0,
            "inputs": [
               {
                  "parent": 0,
                  "parentAxis": 1,
                  "currentValue": 327,
                  "overrideLimits": true,
                  "limits": {
                     "max": 560,
                     "min": 560,
                     "center": 327,
                     "rate": 100,
                     "expo": {
                        "above": 1.5,
                        "below": 1.5
                     }
                  }
               },
               {
                  "parent": 0,
                  "parentAxis": 0,
                  "currentValue": 327,
                  "overrideLimits": true,
                  "limits": {
                     "max": 560,
                     "min": 560,
                     "center": 327,
                     "rate": 100,
                     "expo": {
                        "above": 1.5,
                        "below": 1.5
                     }
                  }
               },
               {
                  "parent": 3,
                  "parentAxis": 0,
                  "currentValue": 327,
                  "overrideLimits": true,
                  "limits": {
                     "max": 560,
                     "min": 560,
                     "center": 327,
                     "rate": 100,
                     "expo": {
                        "above": 1.5,
                        "below": 1.5
                     }
                  }
               }
            ]
         }
      ]
   },
   {
      "type": "switch",
      "icon": "&#128280;",
      "name": "Servo switch control",
      "position": {
         "X": 5,
         "Y": 449
      },
      "cssClass": "default",
      "notes": "",
      "groups": [
         {
            "label": "Flaps",
            "channel": 5,
            "enabled": true,
            "switches": [
               {
                  "label": "Flaps Up",
                  "value": 560,
                  "active": false
               },
               {
                  "label": "Flaps Down",
                  "value": 150,
                  "active": true
               }
            ]
         },
         {
            "label": "Lights",
            "channel": 6,
            "enabled": true,
            "switches": [
               {
                  "label": "Lights On",
                  "value": 560,
                  "active": false
               },
               {
                  "label": "Lights Off",
                  "value": 150,
                  "active": true
               }
            ]
         },
         {
            "label": "Aux 1",
            "channel": 9,
            "enabled": true,
            "switches": [
               {
                  "label": "0%",
                  "value": 150,
                  "active": false
               },
               {
                  "label": "50%",
                  "value": 327,
                  "active": false
               },
               {
                  "label": "100%",
                  "value": 560,
                  "active": true
               }
            ]
         },
         {
            "label": "HL",
            "channel": 0,
            "enabled": true,
            "switches": [
               {
                  "label": "On",
                  "value": 150,
                  "active": false
               },
               {
                  "label": "Off",
                  "value": 560,
                  "active": true
               }
            ]
         }
      ]
   },
   {
      "type": "joystick",
      "name": "Right Stick",
      "icon": "&#127918;",
      "notes": "",
      "position": {
         "X": 490,
         "Y": 88
      },
      "size": {
         "width": 300,
         "height": 300
      },
      "joySize": {
         "width": 65,
         "height": 65
      },
      "cssClass": "default",
      "panel": ".controls",
      "axis": [
         {
            "name": "X Axis",
            "channel": 10,
            "axis": "X",
            "enabled": true,
            "springTension": 150,
            "currentValue": 327,
            "limits": {
               "max": 560,
               "min": 150,
               "center": 327,
               "rate": 100,
               "expo": {
                  "above": 1.5,
                  "below": 1.5
               }
            }
         },
         {
            "name": "Y Axis",
            "channel": 12,
            "axis": "Y",
            "enabled": true,
            "springTension": 150,
            "currentValue": 329,
            "limits": {
               "max": 560,
               "min": 150,
               "center": 329,
               "rate": 100,
               "expo": {
                  "above": 1,
                  "below": 1
               }
            }
         }
      ]
   },
   {
      "icon": "&#127918;",
      "type": "joystick",
      "name": "Left Track",
      "notes": "",
      "position": {
         "X": 5,
         "Y": 88
      },
      "size": {
         "width": 100,
         "height": 300
      },
      "joySize": {
         "width": 65,
         "height": 65
      },
      "cssClass": "default",
      "panel": ".controls",
      "axis": [
         {
            "name": "X",
            "channel": 1,
            "axis": "X",
            "enabled": false,
            "springTension": 150,
            "currentValue": 327,
            "limits": {
               "max": 560,
               "min": 150,
               "center": 327,
               "rate": 100,
               "expo": {
                  "above": 1.5,
                  "below": 1.5
               }
            }
         },
         {
            "name": "Y",
            "channel": 0,
            "axis": "Y",
            "enabled": true,
            "springTension": 150,
            "currentValue": 327,
            "limits": {
               "max": 560,
               "min": 150,
               "center": 327,
               "rate": 100,
               "expo": {
                  "above": 1.5,
                  "below": 1.5
               }
            }
         }
      ]
   },
   {
      "icon": "&#127918;",
      "type": "joystick",
      "name": "New Joystick",
      "notes": "",
      "position": {
         "X": 800,
         "Y": 88
      },
      "size": {
         "width": 100,
         "height": 300
      },
      "joySize": {
         "width": 65,
         "height": 65
      },
      "cssClass": "default",
      "panel": ".controls",
      "axis": [
         {
            "name": "X",
            "channel": 1,
            "axis": "X",
            "enabled": false,
            "springTension": 150,
            "currentValue": 327,
            "limits": {
               "max": 560,
               "min": 150,
               "center": 327,
               "rate": 100,
               "expo": {
                  "above": 1.5,
                  "below": 1.5
               }
            }
         },
         {
            "name": "Y",
            "channel": 0,
            "axis": "Y",
            "enabled": true,
            "springTension": 150,
            "currentValue": 327,
            "limits": {
               "max": 560,
               "min": 150,
               "center": 327,
               "rate": 100,
               "expo": {
                  "above": 1.5,
                  "below": 1.5
               }
            }
         }
      ]
   }
]