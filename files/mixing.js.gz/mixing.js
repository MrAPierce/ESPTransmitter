﻿define(function() {

   function mixTypeMin(arr) {
      return arr.Min();
   }

   function mixTypeMax(arr) {
      return arr.Max();
   }

   function mixTypeAvg(arr) {
      return parseInt((arr.reduce(function (a, b) {
         return a + b;
      })) / arr.length);
   }

   Array.prototype.Max = function () {
      return Math.max.apply(null, this);
   };

   Array.prototype.Min = function() {
      return Math.min.apply(null, this);
   };

   Number.prototype.clamp = function(min, max) {
      return Math.min(Math.max(this, min), max);
   };

   var mixing = [
      {
         type: "MixTypeMin",
         name: "Minimum",
         excute: mixTypeMin,
         description: "Minimum value mix, takes values and rturns the smallest eg: 1,2,3 returns 1"
      },
      {
         type: "MixTypeMax",
         name: "Maximum",
         excute: mixTypeMax,
         description: "Maximum value mix, takes values and rturns the largest eg: 1,2,3 returns 3"
      },
      {
         type: "MixTypeAvg",
         name: "Average",
         excute: mixTypeAvg,
         description: "Average value mix, takes values and rturns the average eg: 1,2,3 returns 2"
      }
   ];

   var getMixByType = function(type) {
      for (var i = 0; i < mixing.length; i++) {
         if (mixing[i].type === type) {
            return mixing[i];
         }
      }

      throw "Couldn't find mixing: " + type;
   };

   return {
      allMixes: mixing,
      getMixByType: getMixByType
   };
});