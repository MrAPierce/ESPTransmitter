define(["knockout", "text!servoslave.display.html", "mixing", "expo", "mapping"], function (ko, template, mixing, expo, mapping) {
   function servoSlave(model) {

      var viewModel = {};
      var parentSubscriptions = [];
      var editViewModel = {};
      var controller = model;
      var controlModel = mapping.fromJS(model.rawControl);
      var editControl = model.openEditor;
      var id = model.id;
      var worker = model.worker;

      var out = ko.observableArray([]);
      var outputInputArraySubscriptions = [];
      viewModel.outputLabels = ko.observableArray([]);

      var newOutput = {
         name: "New Output",
         notes: "Add your output description",
         enabled: true,
         channel: 1,
         type: "MixTypeMax",
         currentValue: 0,
         inputs: []
      };

      var updateMixingType = function (outputId, output) {
         var type = output.type();
         var mixingType = mixing.getMixByType(type);
         out()[outputId]().mixValues = mixingType.excute;
         out()[outputId].valueHasMutated();
      }

      var calcWidth = function () {
         viewModel.width((controlModel.mixOutputs().length * 56) + 4);
      }

      var removeParentSubscription = function (outputId, inputId) {
         if (parentSubscriptions[outputId][inputId]) {
            parentSubscriptions[outputId][inputId].dispose();
            parentSubscriptions[outputId][inputId] = null;
         }
      }

      var removeOutput = function (outputId) {
         var sure = confirm("Delete output?");
         if (sure) {
            var output = controlModel.mixOutputs()[outputId];
            var inputs = output.inputs;
            ko.utils.arrayForEach(inputs(), function(input, inputId) {
               removeParentSubscription(outputId, inputId);
            });
            controlModel.mixOutputs.splice(outputId, 1);
            viewModel.outputLabels.splice(outputId, 1);
            viewModel.outputs.splice(outputId, 1);
            calcWidth();
         }
      }

      var addOutput = function (output, i) {

         editViewModel.parentLimits.push([]);
         editViewModel.validInput.push([]);
         editViewModel.outputVisible.push(ko.observable(false));
         outputInputArraySubscriptions.push([]);
         parentSubscriptions.push([]);

         var mixingType = mixing.getMixByType(output.type());
         out.push(ko.observable({
            values: [],
            channel: output.channel(),
            mixValues: mixingType.excute,
            outputId: i
         }));

         viewModel.outputLabels.push({
            enabled: output.enabled,
            currentPosition: ko.observable().extend({
               notify: "always",
               rateLimit: model.RefreshRate()
            })
         });

         out()[i].subscribe(function (obj) {
            if (output.enabled()) {
               if (obj.values.length > 0) {
                  var val = obj.mixValues(obj.values);
                  worker.sendInputChange(obj.channel, val);
                  viewModel.outputLabels()[obj.outputId].currentPosition(parseInt(val));
               }
            }
         });

         viewModel.outputs.push({
            enabled: output.enabled,
            channel: output.channel
         });

      }

      var addNewOutput = function () {
         var mappedOutput = mapping.fromJS(newOutput);
         editViewModel.outputVisible.push(ko.observable(false));
         controlModel.mixOutputs.push(mappedOutput);

         calcWidth();
         addOutput(mappedOutput, controlModel.mixOutputs.length+1);
      }

      var subscribeInputValuesArray = function (outputId, inputId, output) {
         outputInputArraySubscriptions[outputId][inputId] = output.inputs()[inputId].currentValue.subscribe(function (value) {
            out()[outputId]().values[inputId] = parseInt(value);
            out()[outputId].valueHasMutated();
         });
      }

      var bindParentAxisToInput = function (outputId, inputId, input, parentAxis) {

         if (parentSubscriptions[outputId][inputId] == null) {

            parentSubscriptions[outputId][inputId] = parentAxis.currentValue.subscribe(function (value) {
               
               if (!input.overrideLimits()) {
                  input.currentValue(value);
               } else {
                  var mapped;
                  var movePercentage;
                  var expoValue;
                  if (value < parentAxis.limits.center()) {
                     movePercentage = expo.map(value, parentAxis.limits.min(), parentAxis.limits.center(), 0, 50);
                     mapped = expo.map(movePercentage, 0, 50, input.limits.min(), input.limits.center());
                     expoValue = expo.mapExpo(mapped, input.limits.expo.below(), input.limits.min(), input.limits.center());
                  } else {
                     movePercentage = expo.map(value, parentAxis.limits.center(), parentAxis.limits.max(), 50, 100);
                     mapped = expo.map(movePercentage, 50, 100, input.limits.center(), input.limits.max());
                     expoValue = expo.mapExpo(mapped, input.limits.expo.above(), input.limits.center(), input.limits.max());
                  }
                  input.currentValue(parseInt(expoValue.value));
               }
            });

            var limitObj = parentAxis.limits;
            if (input.overrideLimits()) {
               limitObj = input.limits;
            };

            out()[outputId]().values.push(limitObj.center());
            out()[outputId].valueHasMutated();
         }
      }

      var addInput = function (outputId, koModel) {

         var parentId = editViewModel.newInputSelection();
         var parentControl = model.findControlById(parentId);

         var selectedParentAxis;

         ko.utils.arrayForEach(parentControl.axis(), function (axis, i) {
            if (i === editViewModel.newInputControlAxisSelection()) {
               selectedParentAxis = axis;
            }
         });

         var parentLimitObj = mapping.toJS(selectedParentAxis.limits);

         var newInput = {
            parent: parentId,
            parentAxis: editViewModel.newInputControlAxisSelection(),
            currentValue: selectedParentAxis.limits.center(),
            overrideLimits: false,
            limits: parentLimitObj
         };

         var newInputModel = mapping.fromJS(newInput);

         editViewModel.validInput()[outputId].push({ valid: true, name: parentControl.name, axisName: selectedParentAxis.name });

         editViewModel.parentLimits()[outputId].push(selectedParentAxis.limits);
         controlModel.mixOutputs()[outputId].inputs.push(newInputModel);

         // minus one?????
         var newInputId = koModel.inputs().length - 1;

         subscribeInputValuesArray(outputId, newInputId, koModel);
         bindParentAxisToInput(outputId, newInputId, newInputModel, selectedParentAxis);

         return true;
      }

      var removeInput = function (outputId, inputId, parent) {
         var sure = confirm("Remove this input?");
         if (sure) {
            removeParentSubscription(outputId, inputId);
            parent.inputs.splice(inputId, 1);
            out()[outputId]().values.splice(inputId, 1);
            out()[outputId].valueHasMutated();
         }
      }

      var toggleOutputVisiblity = function (index) {
         var visibilty = editViewModel.outputVisible()[index];
         visibilty(!visibilty());
      }

      var edit = function () {

         var inputControls = controller.findControlsByType(["joystick"], [id]);
         editViewModel.inputControls = inputControls;

         editViewModel.newInputSelection = ko.observable();
         editViewModel.newInputControlAxis = ko.observableArray([]);
         editViewModel.newInputControlAxisSelection = ko.observable();

         editViewModel.newInputSelection.subscribe(function (index) {
            editViewModel.newInputControlAxis([]);
            inputControls.forEach(function (selectedControl) {
               if (selectedControl.id === index) {
                  ko.utils.arrayForEach(selectedControl.control.axis(), function (axis, i) {
                     editViewModel.newInputControlAxis.push({ id: i, axis: axis });
                  });
               }
            });
         });

         editViewModel.newInputSelection(0);

         var model = {
            control: controlModel,
            mixingTypes: mixing.allMixes,
            viewModel: editViewModel,
            toggleOutput: toggleOutputVisiblity,
            addNewOutput: addNewOutput,
            id: id
         }
         editControl(model, "servoslave.editor.html");
      };

      viewModel.left = controlModel.position.X;
      viewModel.top = controlModel.position.Y;
      viewModel.width = ko.observable();
      calcWidth();
      viewModel.height = ko.observable(50);
      viewModel.outputs = ko.observableArray([]);
      editViewModel.outputVisible = ko.observableArray([]);
      editViewModel.parentLimits = ko.observableArray([]);
      editViewModel.valid = ko.observable(true);
      editViewModel.validInput = ko.observableArray([]);
      editViewModel.overrideInputLimit = ko.observableArray([]);
      editViewModel.removeInput = removeInput;
      editViewModel.addInput = addInput;
      editViewModel.updateMix = updateMixingType;
      editViewModel.removeOutput = removeOutput;

      for (var i = 0; i < controlModel.mixOutputs().length; i++) {

         var output = controlModel.mixOutputs()[i];

         editViewModel.validInput.push([]);

         addOutput(output, i);         

         for (var k = 0; k < output.inputs().length; k++) {
            var input = output.inputs()[k];

            subscribeInputValuesArray(i, k, output);
            
            if (model.id !== input.parent()) {
               var parentControl = model.findControlById(input.parent());
               if (parentControl) {

                  var parentAxis = parentControl.axis()[input.parentAxis()];
                  editViewModel.parentLimits()[i].push(parentAxis.limits);
                  editViewModel.validInput()[i].push({ valid: true, name: parentControl.name, axisName: parentAxis.name });
                  bindParentAxisToInput(i, k, input, parentAxis);

               } else {
                  //TODO move to validate control function, will be called elsewhere.
                  editViewModel.validInput()[i].push({ valid: false, message: "Input error: Parent input not found, please remove" });
                  editViewModel.valid(false);
               }
            } else {
               editViewModel.validInput()[i].push({ valid: false, message: "Input Error: Parent input cannot be self, please remove" });
               editViewModel.valid(false);
            }

         };
      };

      viewModel.edit = edit;

      model.getControlModel = function () {
         return { id: id, control: controlModel };
      }

      model.finishedLoading({ id: model.id });

      return viewModel;

   }

   return {
      viewModel: servoSlave,
      template: template
   }
});