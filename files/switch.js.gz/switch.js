﻿define(["knockout", "mapping", "text!switch.display.html"], function (ko, mapping, template) {
   function create(model) {

      var viewModel = {};
      var editViewModel = {};
      var controlModel = mapping.fromJS(model.rawControl);
      var editControl = model.openEditor;
      var id = model.id;
      var worker = model.worker;

      var newButtonName = ko.observable("");
      var newButtonValue = ko.observable(327);
      var newGroup = {
         label: "AUX",
         channel: 0,
         enabled: true,
         switches: []
      }

      var removeSwitch = function (groupId, switchId) {
         var sure = confirm("Delete switch?");
         if (sure) {
            var group = controlModel.groups()[groupId];
            group.switches.splice(switchId, 1);
         }
      }

      var addSwitch = function (groupId) {
         if (newButtonName() !== "") {
            var newSwitch = {
               label: newButtonName(),
               value: newButtonValue(),
               active: false
            };
            var mappedSwitch = mapping.fromJS(newSwitch);
            controlModel.groups()[groupId].switches.push(mappedSwitch);
            newButtonName("");
         }
      }

      var addGroup = function () {
         var mappedGroup = mapping.fromJS(newGroup);
         editViewModel.groupVisible.push(ko.observable(false));
         controlModel.groups.push(mappedGroup);

      }

      var removeGroup = function (groupId) {
         var sure = confirm("Delete Group?");
         if (sure) {
            controlModel.groups.splice(groupId, 1);
         }
      }

      var edit = function () {
         var model = {
            control: controlModel,
            viewModel: editViewModel,
            id: id
         }
         editControl(model, "switch.editor.html");
      };

      var toggle = function (group, i) {
         ko.utils.arrayForEach(group.switches(), function (switchObj, b) {
            if (i === b) {
               if (group.enabled()) {
                  worker.sendInputChange(group.channel(), switchObj.value());
               }
            }
            switchObj.active(i === b);
         });
      }

      var toggleGroup = function (index) {
         var visibilty = editViewModel.groupVisible()[index];
         visibilty(!visibilty());

      }

      viewModel.left = controlModel.position.X;
      viewModel.top = controlModel.position.Y;
      viewModel.height = ko.observable(50);
      viewModel.groups = controlModel.groups;
      viewModel.groupContainerWidth = ko.observableArray([]);
      viewModel.edit = edit;
      viewModel.toggle = toggle;

      editViewModel.removeGroup = removeGroup;
      editViewModel.addGroup = addGroup;
      editViewModel.newButtonName = newButtonName;
      editViewModel.newButtonValue = newButtonValue;
      editViewModel.removeSwitch = removeSwitch;
      editViewModel.addSwitch = addSwitch;
      editViewModel.groupVisible = ko.observableArray([]);
      editViewModel.toggleGroup = toggleGroup;

      ko.utils.arrayForEach(controlModel.groups(), function () {
         editViewModel.groupVisible.push(ko.observable(false));
      });

      model.finishedLoading({ id: model.id });
      model.getControlModel = function () {
         return { id: id, control: controlModel };
      }

      return viewModel;
   }
   return {
      viewModel: create,
      template: template
   }

});